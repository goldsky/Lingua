<?php
namespace Lingua\Model;

use xPDO\xPDO;

/**
 * Class LinguaSiteTmplvars
 *
 * @property integer $tmplvarid
 *
 * @property \LinguaSiteTmplvarContentvalues[] $TmplvarContentvalues
 *
 * @package Lingua\Model
 */
class LinguaSiteTmplvars extends \xPDO\Om\xPDOSimpleObject
{
}
