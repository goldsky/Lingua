<?php
namespace Lingua\Model;

use xPDO\xPDO;

/**
 * Class LinguaSiteTmplvarsPatterns
 *
 * @property string $type
 * @property string $search
 * @property string $replacement
 *
 * @package Lingua\Model
 */
class LinguaSiteTmplvarsPatterns extends \xPDO\Om\xPDOSimpleObject
{
}
